# International Language Support

Chrome Webstore Locale Support.

Please help us to translate: https://keptab.com/locale

## TODO: Locale code Language (region)
- [ ] ar     Arabic
- [ ] am     Amharic
- [ ] bg     Bulgarian
- [ ] bn     Bengali
- [ ] ca     Catalan
- [ ] cs     Czech
- [ ] da     Danish
- [ ] de     German
- [ ] el     Greek
- [x] en     English
- [x] en_GB  English (Great Britain)
- [x] en_US  English (USA)
- [ ] es     Spanish
- [ ] es_419 Spanish (Latin America and Caribbean)
- [ ] et     Estonian
- [ ] fa     Persian
- [ ] fi     Finnish
- [ ] fil    Filipino
- [ ] fr     French
- [ ] gu     Gujarati
- [ ] he     Hebrew
- [ ] hi     Hindi
- [ ] hr     Croatian
- [ ] hu     Hungarian
- [ ] id     Indonesian
- [ ] it     Italian
- [ ] ja     Japanese
- [ ] kn     Kannada
- [ ] ko     Korean
- [ ] lt     Lithuanian
- [ ] lv     Latvian
- [ ] ml     Malayalam
- [ ] mr     Marathi
- [ ] ms     Malay
- [ ] nl     Dutch
- [ ] no     Norwegian
- [ ] pl     Polish
- [ ] pt_BR  Portuguese (Brazil)
- [ ] pt_PT  Portuguese (Portugal)
- [ ] ro     Romanian
- [ ] ru     Russian
- [ ] sk     Slovak
- [ ] sl     Slovenian
- [ ] sr     Serbian
- [ ] sv     Swedish
- [ ] sw     Swahili
- [ ] ta     Tamil
- [ ] te     Telugu
- [ ] th     Thai
- [ ] tr     Turkish
- [ ] uk     Ukrainian
- [ ] vi     Vietnamese
- [x] zh_CN  Chinese (China)
- [x] zh_TW  Chinese (Taiwan)


